package com.insurance.insuranceCompany.controller;

import java.time.LocalTime;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.insurance.insuranceCompany.model.Login;
import com.insurance.insuranceCompany.service.EmailService;
import com.insurance.insuranceCompany.service.LoginService;

@Controller
@RequestMapping("/insurance")
public class EmailController {

	private LoginService logService;
	private EmailService mailService;
	private HttpSession httpSession;

	@Autowired
	public EmailController(EmailService mailService, HttpSession httpSession, LoginService logService) {
		this.mailService = mailService;
		this.httpSession = httpSession;
		this.logService = logService;
	}

	@GetMapping("/email")
	@ResponseBody
	public String email(@RequestParam("to") String to_mail) {

		if (mailService.checkMail(to_mail) == 1) {
			httpSession.setAttribute("email", to_mail);
			// storing generated otp
			int OTP = mailService.sendmail(to_mail);

			httpSession.setAttribute("time", LocalTime.now());
			httpSession.setAttribute("OTP", OTP);

			return "Email Sent Successfully";
		} else
			return "Email not registered";

	}

	@PostMapping(value = "/validateOTP")
	public ModelAndView validateOTP(@RequestParam("otp") String otp, Model model) {
		model.addAttribute("to", "");
		int enteredOTP = Integer.parseInt(otp);

		ModelAndView mav = new ModelAndView();
		int storedOtp = (Integer) httpSession.getAttribute("OTP");
		String email = (String) httpSession.getAttribute("email");
		LocalTime OtpStoredTime = (LocalTime) httpSession.getAttribute("time");
		int comp = OtpStoredTime.compareTo(LocalTime.now());

		if (storedOtp == enteredOTP && comp <= 5) { // checking the otp and time
			mav.setViewName("reset");
			mav.addObject("email", email);
			return mav;
		}
		mav.setViewName("forgotPasswordPage");
		if (comp > 5)
			mav.addObject("msg", "OTP expired, please try again..");
		else
			mav.addObject("msg", "Invalid OTP, please try again..");
		mav.addObject("to", email);
		return mav;
	}

	@PostMapping("/reset")
	public String reset(Model model, @RequestParam("email") String email, @RequestParam("pwd") String pwd,
			@RequestParam("cnfpwd") String cnfpwd) {
		if (logService.resetpwd(email, pwd) == 1) // resetting the password to the given mail
			model.addAttribute("message", "password changed");
		else
			model.addAttribute("message", "error while password changing");
		model.addAttribute("login", new Login());
		return "loginPage";
	}
}
