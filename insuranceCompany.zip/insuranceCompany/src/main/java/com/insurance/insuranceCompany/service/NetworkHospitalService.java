package com.insurance.insuranceCompany.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.insurance.insuranceCompany.Dao.NetworkHospitalDao;
import com.insurance.insuranceCompany.model.InsurancePackage;
import com.insurance.insuranceCompany.model.NetworkHospitals;
@Service
public class NetworkHospitalService {
	@Autowired
	private NetworkHospitalDao nhdao;
	public ArrayList<NetworkHospitals> getAllHospitals() {
		return nhdao.getAllHopitals();
	}
	
	public int editHospital(NetworkHospitals netHsp) {
		return nhdao.editHospital(netHsp);
	}
	
	public ArrayList<InsurancePackage> getRelatedPackages(int hspid) {
		return nhdao.getRelatedPackages(hspid);
	}
	
	public ArrayList<NetworkHospitals> getSearchHospitals(String search) {
		return nhdao.getSearcHospitals(search);
	}
}
